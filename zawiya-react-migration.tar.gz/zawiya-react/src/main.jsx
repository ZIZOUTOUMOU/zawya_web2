// frontend-react/src/main.jsx
// Entry point — mounts the React app into the DOM

import { StrictMode } from 'react'
import { createRoot }  from 'react-dom/client'
import App from './App.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>
)
